# Express Filesystem Template

This starter project wires up `nodemon`, `express`, and `uuid` for assignment 5. Copy this folder/these files and run `npm install` to pull down dependencies and get started.

You may run the Express server via `npm start`. This will invoke the `main.js` file using `nodemon` to hot-reload your code as you make changes.